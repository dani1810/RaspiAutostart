Contributors
============

In alphabetic order:

- "ijk"
- Adomas Paltanavičius
- Barry Warsaw
- Chris Beaven
- Christian Theune
- Dafydd Harries
- Daniel Kraft
- Danielle Madeley
- Eduardo Habkost
- Emanuele Aina
- Gaute Amundsen
- Gintautas Miliauskas
- Harald Friessnegger
- Ignas Mikalajūnas
- Jamu Kakar
- Jean Jordaan
- Jeroen Langeveld
- Jonatan Cloutier
- Kees Cook
- Lars Wirzenius
- Laurynas Speičys
- Martin Pitt
- Michael Vogt
- Olivier Crête
- Patrick Gerken
- Radek Muzatko
- Rodrigo Daunoravicius
- Rohan Mitchell
- Thom May
- Tomaz Canabrava
- Živilė Gedminaitė

Their contributions include patches (including those that didn't make it into
the mainline), helpful suggestions, icons, configuration tips for integration
with other software, offers for co-maintainership.

Apologies to anyone I may have omitted.  If you drop me a note, I'll correct
the omission.
