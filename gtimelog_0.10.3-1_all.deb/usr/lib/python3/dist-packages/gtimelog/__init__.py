# The gtimelog package.

__version__ = '0.10.3'
